#include "BmpProcessor.h"

/**
 * read BMP header of a file. Useful for converting files from PPM to BMP.
 *
 * @param  file: A pointer to the file being read or written
 * @param  header: Pointer to the destination BMP header
 */
void readBMPHeader(FILE* file, struct BMP_Header* header){
    fseek(file, 0, SEEK_SET);
    fread(&header->signature, sizeof(char) * 2, 1, file);
    fread(&header->size, sizeof(int), 1, file);
    fread(&header->reserved1, sizeof(short), 1, file);
    fread(&header->reserved2, sizeof(short), 1, file);
    fread(&header->offset_pixel_array, sizeof(int), 1, file);
}

/**
 * write BMP header of a file. Useful for converting files from PPM to BMP.
 *
 * @param  file: A pointer to the file being read or written
 * @param  header: The header made by makeBMPHeader function
 */
void writeBMPHeader(FILE* file, struct BMP_Header* header){
    fseek(file, 0, SEEK_SET);
    fwrite(&header->signature, sizeof(char) * 2, 1, file);
    fwrite(&header->size, sizeof(int), 1, file);
    fwrite(&header->reserved1, sizeof(short), 1, file);
    fwrite(&header->reserved2, sizeof(short), 1, file);
    fwrite(&header->offset_pixel_array, sizeof(int), 1, file);
}

/**
 * read DIB header from a file. Useful for converting files from PPM to BMP.
 *
 * @param  file: A pointer to the file being read or written
 * @param  header: Pointer to the destination DIB header
 */
void readDIBHeader(FILE* file, struct DIB_Header* header){
    fseek(file, 14, SEEK_SET);
    fread(&header->DIB_header_size, sizeof(int), 1, file);
    fread(&header->width, sizeof(int), 1, file);
    fread(&header->height, sizeof(int), 1, file);
    fread(&header->planes, sizeof(short), 1, file);
    fread(&header->bits_per_pixel, sizeof(short), 1, file);
    fread(&header->compression, sizeof(int), 1, file);
    fread(&header->size, sizeof(int), 1, file);
    fread(&header->x_pixels_per_meter, sizeof(int), 1, file);
    fread(&header->y_pixels_per_meter, sizeof(int), 1, file);
    fread(&header->colors_in_color_tables, sizeof(int), 1, file);
    fread(&header->important_color_count, sizeof(int), 1, file);
}

/**
 * write DIB header of a file. Useful for converting files from PPM to BMP.
 *
 * @param  file: A pointer to the file being read or written
 * @param  header: The header made by makeDIBHeader function
 */
void writeDIBHeader(FILE* file, struct DIB_Header* header){
    fseek(file, 14, SEEK_SET);
    fwrite(&header->DIB_header_size, sizeof(int), 1, file);
    fwrite(&header->width, sizeof(int), 1, file);
    fwrite(&header->height, sizeof(int), 1, file);
    fwrite(&header->planes, sizeof(short), 1, file);
    fwrite(&header->bits_per_pixel, sizeof(short), 1, file);
    fwrite(&header->compression, sizeof(int), 1, file);
    fwrite(&header->size, sizeof(int), 1, file);
    fwrite(&header->x_pixels_per_meter, sizeof(int), 1, file);
    fwrite(&header->y_pixels_per_meter, sizeof(int), 1, file);
    fwrite(&header->colors_in_color_tables, sizeof(int), 1, file);
    fwrite(&header->important_color_count, sizeof(int), 1, file);
}

/**
 * make BMP header based on width and height.
 * The purpose of this is to create a new BMPHeader struct using the information
 * from a PPMHeader when converting from PPM to BMP.
 *
 * @param  header: Pointer to the destination DIB header
 * @param  width: Width of the image that this header is for
 * @param  height: Height of the image that this header is for
 */
void makeBMPHeader(struct BMP_Header* header, int width, int height){
    int real_width = (width * sizeof(char) * 3) % 4 + width;
    header->signature[0] = 'B';
    header->signature[1] = 'M';
    header->size = 54 + real_width * height;
    header->reserved1 = 0;
    header->reserved2 = 0;
    header->offset_pixel_array = 54;    //14 for BMP Header + 40
                                        //for DIB Header
}


 /**
 * Makes new DIB header based on width and height. Useful for converting files from PPM to BMP.
 *
 * @param  header: Pointer to the destination DIB header
 * @param  width: Width of the image that this header is for
 * @param  height: Height of the image that this header is for
 */
void makeDIBHeader(struct DIB_Header* header, int width, int height){
    int real_width = (width * sizeof(char) * 3) % 4 + width;
    header->DIB_header_size = 40;
    header->width = width;
    header->height = height;
    header->planes = 1;
    header->bits_per_pixel = 24;
    header->compression = 0;
    header->size = real_width * height;
    header->x_pixels_per_meter = 3780;
    header->y_pixels_per_meter = 3780;
    header->colors_in_color_tables = 0;
    header->important_color_count = 0;
}

/**
 * read Pixels from BMP file based on width and height.
 *
 * @param  file: A pointer to the file being read or written
 * @param  pArr: Pixel array of the image that this header is for
 * @param  width: Width of the image that this header is for
 * @param  height: Height of the image that this header is for
 */
void readPixelsBMP(FILE* file, struct Pixel** pArr, int width, int height){
    fseek(file, 54, SEEK_SET);
    int padding = (width * sizeof(char) * 3) % 4;
    char ZERO_ARRAY[4] = {0};
    for(int h = height - 1; h >= 0; h--){
        for(int w = 0; w < width; w++){
            fread(&pArr[h][w].red, sizeof(char), 1, file);
            fread(&pArr[h][w].green, sizeof(char), 1, file);
            fread(&pArr[h][w].blue, sizeof(char), 1, file);
        }
        fread(&ZERO_ARRAY[0], sizeof(char) * padding, 1, file);
    }
}


/**
 * write Pixels from BMP file based on width and height.
 *
 * @param  file: A pointer to the file being read or written
 * @param  pArr: Pixel array of the image that this header is for
 * @param  width: Width of the image that this header is for
 * @param  height: Height of the image that this header is for
 */
void writePixelsBMP(FILE* file, struct Pixel** pArr, int width, int height){
    fseek(file, 54, SEEK_SET);
    int padding = (width * sizeof(char) * 3) % 4;
    short ZERO_ARRAY[4] = {0};
    for(int h = height - 1; h >= 0; h--){
        for(int w = 0; w < width; w++){
            fwrite(&pArr[h][w].red, sizeof(char), 1, file);
            fwrite(&pArr[h][w].green, sizeof(char), 1, file);
            fwrite(&pArr[h][w].blue, sizeof(char), 1, file);
        }
        fwrite(&ZERO_ARRAY[0], sizeof(char) * padding, 1, file);
    }
}
