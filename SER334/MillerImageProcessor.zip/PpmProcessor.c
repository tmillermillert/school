#include "PpmProcessor.h"

/**
 * read PPM header of a file. Useful for converting files from BMP to PPM.
 *
 * @param  file: A pointer to the file being read or written
 * @param  header: Pointer to the destination PPM header
 */
void readPPMHeader(FILE* file, struct PPM_Header* header){
    char next_char = 0;
    int width = 0;
    int height = 0;
    int max_value_for_each_color = 0;
    int width_array[32] = {0};
    int height_array[32] = {0};
    int max_value_for_each_color_array[32] = {0};
    int count = 0;
    fread(&header->magic_number, sizeof(char) * 2, 1, file);
    fread(&next_char, sizeof(char), 1, file);
    if(!(next_char == '\n' || next_char == '\t' || next_char == 13)){//CR = 13
         exit(1);
    }
    fread(&next_char, sizeof(char), 1, file);
    while(next_char >= '0' && next_char <= '9'){
        width_array[count++] = next_char - '0';
        fread(&next_char, sizeof(char), 1, file);
    }
    int power = 0;
    for(int i = count - 1; i >= 0; i--){
        width += width_array[i] * pow(10, power++);
    }
    header->width = width;
    
    count = 0;
    if(!(next_char == '\n' || next_char == '\t' || next_char == 13)){//CR = 13
         exit(1);
    }
    fread(&next_char, sizeof(char), 1, file);
    while(next_char >= '0' && next_char <= '9'){
        height_array[count++] = next_char - '0';
        fread(&next_char, sizeof(char), 1, file);
    }
    power = 0;
    for(int i = count - 1; i >= 0; i--){
        height += height_array[i] * pow(10, power++);
    }
    if(!(next_char == '\n' || next_char == '\t' || next_char == 13)){//CR = 13
         exit(1);
    }
    header->height = height;
    
    count = 0;
    if(!(next_char == '\n' || next_char == '\t' || next_char == 13)){//CR = 13
         exit(1);
    }
    fread(&next_char, sizeof(char), 1, file);
    while(next_char >= '0' && next_char <= '9'){
        max_value_for_each_color_array[count++] = next_char - '0';
        fread(&next_char, sizeof(char), 1, file);
    }
    power = 0;
    for(int i = count - 1; i >= 0; i--){
        max_value_for_each_color += max_value_for_each_color_array[i] * pow(10, power++);
    }
    if(!(next_char == '\n' || next_char == '\t' || next_char == 13)){//CR = 13
         exit(1);
    }
    header->max_value_for_each_color = max_value_for_each_color;
}

/**
 * write PPM header of a file. Useful for converting files from BMP to PPM.
 *
 * @param  file: A pointer to the file being read or written
 * @param  header: The header made by makePPMHeader function

 */
void writePPMHeader(FILE* file, struct PPM_Header* header){
    int next_int = 0;
    int width = header->width;
    int height = header->height;
    int max_value_for_each_color = header->max_value_for_each_color;
    char width_array[32] = {0};
    char height_array[32] = {0};
    char max_value_for_each_color_array[32] = {0};
    
    fwrite(&header->magic_number, sizeof(char) * 2, 1, file);
    fwrite("\n", sizeof(char), 1, file);
    
    
    int count = 0;
    while(width != 0){
        next_int = width % 10;
        width = width / 10;
        width_array[count++] = next_int + '0';
    }
    for(int i = count - 1; i >= 0; i--){
        fwrite(&width_array[i], sizeof(char), 1, file);
    }
    fwrite("\n", sizeof(char), 1, file);
    
    count = 0;
    while(height != 0){
        next_int = height % 10;
        height = height / 10;
        height_array[count++] = next_int + '0';
    }
    for(int i = count - 1; i >= 0; i--){
        fwrite(&height_array[i], sizeof(char), 1, file);
    }
    fwrite("\n", sizeof(char), 1, file);
    
    count = 0;
    while(max_value_for_each_color != 0){
        next_int = max_value_for_each_color % 10;
        max_value_for_each_color = max_value_for_each_color / 10;
        max_value_for_each_color_array[count++] = next_int + '0';
    }
    for(int i = count - 1; i >= 0; i--){
        fwrite(&max_value_for_each_color_array[i], sizeof(char), 1, file);
    }
    fwrite("\n", sizeof(char), 1, file);

}

/**
 * make PPM header based on width and height. Useful for converting files from BMP to PPM.
 *
 * @param  header: Pointer to the destination PPM header
 * @param  width: Width of the image that this header is for
 * @param  height: Height of the image that this header is for
 */
void makePPMHeader(struct PPM_Header* header, int width, int height){
    header->magic_number[0] = 'P';
    header->magic_number[1] = '6';
    header->width = width;
    header->height = height;
    header->max_value_for_each_color = 255;
}

/**
 * read Pixels from PPM file based on width and height.
 *
 * @param  file: A pointer to the file being read or written
 * @param  pArr: Pixel array of the image that this header is for
 * @param  width: Width of the image that this header is for
 * @param  height: Height of the image that this header is for
 */
void readPixelsPPM(FILE* file, struct Pixel** pArr, int width, int height){
    fseek(file, 0, SEEK_SET);
    char next_char = 0;
    int count = 0;
    while(count < 4){
        fread(&next_char, sizeof(char), 1, file);
        if(next_char == '\n' || next_char == '\t' || next_char == 13){//CR = 13
            count++;
        }
    }

    for (int h = 0; h < height; h++){
        for(int w = 0; w < width; w++){
            //printf("%lu\n", fread(&pArr[h][w].red, sizeof(char), 1, file));
            fread(&pArr[h][w].red, sizeof(char), 1, file);
            fread(&pArr[h][w].green, sizeof(char), 1, file);
            fread(&pArr[h][w].blue, sizeof(char), 1, file);
            //printf("red=%d, green=%d, blue=%d\n", pArr[h][w].red, pArr[h][w].green, pArr[h][w].blue);
        }
    }
}

/**
 * write Pixels from PPM file based on width and height.
 *
 * @param  file: A pointer to the file being read or written
 * @param  pArr: Pixel array of the image that this header is for
 * @param  width: Width of the image that this header is for
 * @param  height: Height of the image that this header is for
 */
void writePixelsPPM(FILE* file, struct Pixel** pArr, int width, int height){
    int width_copy = width;
    int height_copy = height;
    int count = 3; // 2 for magic + \n
    while(width != 0){
        count++;
        width /= 10;
    }
    count++; //\n
    while(height != 0){
        count++;
        height /= 10;
    }
    count++; //\n
    count += 4; //255 + \n
    
    fseek(file, 0, SEEK_SET);
    fseek(file, count, SEEK_SET);
    width = width_copy;
    height = height_copy;
    
    for (int h = 0; h < height; h++){
        for(int w = 0; w < width; w++){
            //printf("%lu\n", fwrite(&pArr[h][w].red, sizeof(int), 1, file));
            fwrite(&pArr[h][w].red, sizeof(char), 1, file);
            fwrite(&pArr[h][w].green, sizeof(char), 1, file);
            fwrite(&pArr[h][w].blue, sizeof(char), 1, file);
            //printf("red=%d, green=%d, blue=%d\n", pArr[h][w].red, pArr[h][w].green, pArr[h][w].blue);
        }
    }
}
