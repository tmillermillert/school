

#include <stdio.h>
#include <unistd.h>
#include <limits.h>
#include <string.h>
#include <errno.h>
#include "PpmProcessor.h"
#include "PixelProcessor.h"
#include "BmpProcessor.h"

int main(int argc, const char * argv[]) {
    // insert code here...
    //int getopt (int argc, char *const *argv, const char *options)
    char c;
    int red_shift = 0;
    int green_shift = 0;
    int blue_shift = 0;
    char output_name_array[1024] = {0};
    char output_extention_array[1024] = {0};
    char output_file_name_array[1024] = {0};
    char input_name_array[1024] = {0};
    char input_extention_array[1024] = {0};
    char input_file_name_array[1024] = {0};
    int first_time = 0;
    
    strcpy(output_extention_array,"ppm");
    strcpy(output_name_array,"a");
    
    struct PPM_Header* ppm_header = (struct PPM_Header*) malloc(sizeof(struct PPM_Header));
    struct BMP_Header* bmp_header = (struct BMP_Header*) malloc(sizeof(struct BMP_Header));
    struct DIB_Header* dib_header = (struct DIB_Header*) malloc(sizeof(struct DIB_Header));
    struct Pixel** pArr;
    int width;
    int height;
    
    if (argv == NULL){
        exit(3);
    }
    
    do {
        c = getopt(argc, argv, "r::g::b::o::t::n::\1:");
        printf("%c-%s\n", c,optarg);
        switch(c){
            case 'r':
                red_shift = atoi(optarg);
                printf("%d\n", red_shift);
                break;
            case 'g':
                green_shift = atoi(optarg);
                printf("%d\n", green_shift);
                break;
            case 'b':
                blue_shift = atoi(optarg);
                printf("%d\n", blue_shift);
                break;
            case 'o':
            case 'n':
                strcpy(output_name_array,optarg );
                printf("%s\n", output_name_array);
                break;
            case 't':
                strcpy(output_extention_array,optarg);
                printf("%s\n", output_extention_array);
                break;
            case -1:
                if (first_time == 1){
                    first_time++;
                    break;
                }
                first_time = 1;
                strcpy(input_file_name_array, argv[optind]);
                printf("%s\n", input_file_name_array);
        }
    } while(c != -1 || first_time == 1);
    
    if(input_file_name_array[0] == 0 || red_shift < 0 || green_shift < 0 || blue_shift < 0 ||
       red_shift > INT_MAX || green_shift > INT_MAX || blue_shift > INT_MAX){
        exit(1);
    }
    if(!(strcmp(output_extention_array, "ppm") == 0 || strcmp(output_extention_array, "bmp") == 0)){
        exit(1);
    }
    
    strcpy(output_file_name_array, output_name_array);
    strcat(output_file_name_array,".");
    strcat(output_file_name_array,output_extention_array);
    
    strcpy(input_name_array, input_file_name_array);
    strcpy(input_extention_array, input_file_name_array);
    strtok(input_name_array, ".");
    char *ptr = NULL;
    strtok(input_extention_array, ".");
    ptr = strtok(NULL, ".");
    char tmp[40] = {0};
    strcpy(tmp,ptr);
    strcpy(input_extention_array,tmp);
    
    

    printf("input:%s=%s.%s\n", input_file_name_array, input_name_array, input_extention_array);
    printf("output:%s=%s.%s\n", output_file_name_array, output_name_array, output_extention_array);
    
    
    FILE *in = fopen(input_file_name_array, "rb");
    if (in == NULL){
        printf("%s\n", strerror(errno));
        exit(2);
    }
    FILE *out = fopen(output_file_name_array, "wb");
    if (out == NULL){
        printf("%s\n", strerror(errno));
        exit(2);
    }
    
    if (strcmp(input_extention_array, "ppm") == 0 && strcmp(output_extention_array, "ppm") == 0){
        readPPMHeader(in, ppm_header);
        writePPMHeader(out, ppm_header);
        
        width = ppm_header->width;
        height = ppm_header->height;
        pArr = (Pixel **) malloc(height * sizeof(Pixel *));
        for (int h = 0; h < height; h++){
            pArr[h]=(Pixel *) malloc(width*sizeof(Pixel));
        }
        
        readPixelsPPM(in, pArr, width, height);
        colorShiftPixels(pArr, width, height, red_shift, green_shift, blue_shift);
        writePixelsPPM(out, pArr, width, height);
        
    }
    else if (strcmp(input_extention_array, "bmp") == 0 && strcmp(output_extention_array, "bmp") == 0){
        readBMPHeader(in, bmp_header);
        writeBMPHeader(out, bmp_header);
        readDIBHeader(in, dib_header);
        writeDIBHeader(out, dib_header);
        
        width = dib_header->width;
        height = dib_header->height;
        pArr = (Pixel **) malloc(height * sizeof(Pixel *));
        for (int h = 0; h < height; h++){
            pArr[h]=(Pixel *) malloc(width*sizeof(Pixel));
        }
        
        readPixelsBMP(in, pArr, width, height);
        colorShiftPixels(pArr, width, height, red_shift, green_shift, blue_shift);
        writePixelsBMP(out, pArr, width, height);
        
    }
    else if (strcmp(input_extention_array, "ppm") == 0 && strcmp(output_extention_array, "bmp") == 0){
        readPPMHeader(in, ppm_header);
        width = ppm_header->width;
        height = ppm_header->height;
        
        pArr = (Pixel **) malloc(height * sizeof(Pixel *));
        for (int h = 0; h < height; h++){
            pArr[h]=(Pixel *) malloc(width*sizeof(Pixel));
        }
        makeBMPHeader(bmp_header, width, height);
        makeDIBHeader(dib_header, width, height);
        writeBMPHeader(out, bmp_header);
        writeDIBHeader(out, dib_header);
        
        
        readPixelsPPM(in, pArr, width, height);
        swap_red_blue(pArr, width, height);
        colorShiftPixels(pArr, width, height, red_shift, green_shift, blue_shift);
        writePixelsBMP(out, pArr, width, height);
        
    }
    else if (strcmp(input_extention_array, "bmp") == 0 && strcmp(output_extention_array, "ppm") == 0){
        readBMPHeader(in, bmp_header);
        readDIBHeader(in, dib_header);
        width = dib_header->width;
        height = dib_header->height;
        
        pArr = (Pixel **) malloc(height * sizeof(Pixel *));
        if (pArr == NULL){
            exit(4);
        }
        for (int h = 0; h < height; h++){
            pArr[h]= malloc(width*sizeof(Pixel));
            if (pArr[h] == NULL){
                exit(5);
            }
        }
        makePPMHeader(ppm_header, width, height);
        writePPMHeader(out, ppm_header);
        
        readPixelsBMP(in, pArr, width, height);
        swap_red_blue(pArr, width, height);
        colorShiftPixels(pArr, width, height, red_shift, green_shift, blue_shift);
        writePixelsPPM(out, pArr, width, height);
        
    }
    else{
        exit(1);
    }
    
    fclose(in);
    fclose(out);
    
    for (int h = 0; h < height; h++){
        free(pArr[h]);
    }
    free(pArr);
    free(dib_header);
    free(bmp_header);
    free(ppm_header);
    
    return 0;
}
