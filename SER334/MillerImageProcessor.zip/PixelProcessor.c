#include "PixelProcessor.h"

/**
 * Shift color of Pixel array. The dimension of the array is width * height. The shift value of RGB is
 * rShift, gShift，bShift. Useful for color shift.
 *
 * @param  pArr: Pixel array of the image that this header is for
 * @param  width: Width of the image that this header is for
 * @param  height: Height of the image that this header is for
 * @param  rShift: the shift value of color r shift
 * @param  gShift: the shift value of color g shift
 * @param  bShift: the shift value of color b shift
 */
void colorShiftPixels(struct Pixel** pArr, int width, int height, int rShift, int gShift, int bShift){
    for(int w = 0; w < width; w++){
        for(int h = 0; h < height; h++){
            int new_red = pArr[h][w].red - rShift;
            int new_green = pArr[h][w].green - gShift;
            int new_blue = pArr[h][w].blue - bShift;
            if(new_red < 0){
                new_red = 0;
            }
            else if(new_red > 255){
                new_red = 255;
            }
            if(new_green < 0){
                new_green = 0;
            }
            else if(new_green > 255){
                new_green = 255;
            }
            if(new_blue < 0){
                new_blue = 0;
            }
            else if(new_blue > 255){
                new_blue = 255;
            }
            pArr[h][w].red = new_red;
            pArr[h][w].green = new_green;
            pArr[h][w].blue = new_blue;
        }
    }
}
void swap_red_blue(struct Pixel** pArr, int width, int height){
    for(int w = 0; w < width; w++){
        for(int h = 0; h < height; h++){
            char tmp = pArr[h][w].red;
            pArr[h][w].red = pArr[h][w].blue;
            pArr[h][w].blue = tmp;
        }
    }
}
