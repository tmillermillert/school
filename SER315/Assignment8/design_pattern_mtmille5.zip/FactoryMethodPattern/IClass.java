public interface IClass {
	
	public String toString();

}
