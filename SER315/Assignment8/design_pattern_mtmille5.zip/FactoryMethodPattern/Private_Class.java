public class Private_Class implements IClass {

	public boolean is_big_room;

	public int id;

	public int time_scheduled;

	public String toString(){
		return "Private Class";
	}

}
