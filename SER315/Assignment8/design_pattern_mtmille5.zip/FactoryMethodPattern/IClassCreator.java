public interface IClassCreator {

	public IClass factoryMethod();

}
