public class Group_Class implements IClass {

	public int max_students;

	public int advanced_or_basic;

	public int id;

	public int time_scheduled;

	public String toString(){
		return "Group Class";
	}

}
