public interface Component{
	public void print();
}