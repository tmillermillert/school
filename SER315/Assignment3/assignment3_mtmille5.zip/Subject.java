import java.util.Collection;

public class Subject {

	public String name;
    public Subject(String s){
        name = s;
    }
    
}
