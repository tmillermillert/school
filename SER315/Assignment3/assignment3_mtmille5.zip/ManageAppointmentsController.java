//import java.util.Collection;
import java.util.ArrayList;

public class ManageAppointmentsController {

	public LoginController loginController;

	public ArrayList<Appointment> appointments;

	public ArrayList<Tutor> tutors;
    
    public ManageAppointmentsController(){
        tutors = new ArrayList<Tutor>();
        appointments = new ArrayList<Appointment>();
    }

}
