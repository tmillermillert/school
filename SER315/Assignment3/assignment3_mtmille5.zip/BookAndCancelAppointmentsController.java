//import java.util.Collection;
import java.util.ArrayList;
import java.time.LocalTime; // import the LocalDateTime class

public class BookAndCancelAppointmentsController {

	public LoginController loginController;

	public ArrayList<Student> students;

	public ArrayList<Appointment> appointments;
    
    public BookAndCancelAppointmentsController(){
        students = new ArrayList<Student>();
        appointments = new ArrayList<Appointment>();
    }
    
    public String bookAppointmentBySubjectAndTime(String email,
                                                       String subject, String time){
       //appointments start at full past the hour or half past the hour
        if (time.length() < 2){
            return "Invalid appointment time!";
        }
        char x = time.charAt(time.length() - 1);
        char y = time.charAt(time.length() - 2);
        if (!((x=='0' && y == '0') || (x == '0' && y == '3'))){
            return "Invalid appointment time!";
        }
        
        //invalid email
        boolean isValidEmail = false;
        Student student = null;
        for (Student s: students){
            if (s.email.equals(email)){
                isValidEmail = true;
                student = s;
                break;
            }
        }
        //insufficient credits
        if (student != null && student.numCredits < 1){
            return "Insufficient credits";
        }
        if (isValidEmail == false){
            return "Email not valid!";
        }
        //invalid subject and no tutor available and student already has appointment
        boolean isValidSubject = false;
        boolean isTutorAvailable = false;
        Appointment appointment = null;
        for (Appointment a: appointments){
            if (a.time.toString().equals(time) && a.student != null && a.student.email.equals(email)){
                return "Student already has appointment at this time";
            }
            for(Subject s:a.tutor.subjects){
                if (s.name.equals(subject)){
                    isValidSubject = true;
                    if (a.student == null && a.time.toString().equals(time)){
                        isTutorAvailable = true;
                        appointment = a;
                        break;
                    }
                }
            }
        }
        if (isValidSubject == false){
            return "Invalid subject!";
        }
        if (appointment == null){
            return "no tutor available";
        }
        //appointment booked
        appointment.student = student;
        return "Appointment booked!";

    }
    
    public String BookAppointmentByID(String email, int id){

        
        //invalid email
        boolean isValidEmail = false;
        Student student = null;
        for (Student s: students){
            if (s.email.equals(email)){
                isValidEmail = true;
                student = s;
                break;
            }
        }
        //insufficient credits
        if (student != null && student.numCredits < 1){
            return "Insufficient credits";
        }
        if (isValidEmail == false){
            return "Email not valid!";
        }

        Appointment appointment = null;
        for (Appointment a: appointments){
            if (a.id == id){
                appointment = a;
                break;
            }
        }
        for (Appointment a: appointments){
            if (a.time == appointment.time && a.student == student){
                return "Student already has appointment at this time";
            }
            if (appointment.student != null){
                return "no tutor available";
            }
        }
        //appointment booked
        appointment.student = student;
        return "Appointment booked!";
        
    }

}
