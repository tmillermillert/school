//import java.util.Collection;
import java.util.ArrayList;

public class ManageSystemController {

	public LoginController loginController;

	public ArrayList<Tutor> tutors;

	public ArrayList<Subject> subjects;

	public ArrayList<Student> students;
    
    public ManageSystemController(){
        tutors = new ArrayList<Tutor>();
        subjects = new ArrayList<Subject>();
        students = new ArrayList<Student>();
    }
}
