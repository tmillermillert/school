import java.time.LocalDateTime; // import the LocalDateTime class
import java.time.LocalTime;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        //LocalDate myObj = LocalDate.now(); // Create a date object
        //System.out.println(myObj); // Display the current date
        LoginController loginController = new LoginController();
        loginController.manager = new Manager("mgr@asu.edu", "Sally Manager", "mgrPass");
        
        BookAndCancelAppointmentsController sAppointmentController = new BookAndCancelAppointmentsController();
        sAppointmentController.loginController = loginController;

        
        ManageAppointmentsController mAppointmentController = new ManageAppointmentsController();
        mAppointmentController.loginController = loginController;
        mAppointmentController.appointments = sAppointmentController.appointments;


        ManageSystemController systemController = new ManageSystemController();
        systemController.tutors = mAppointmentController.tutors;
        systemController.students = sAppointmentController.students;
        
        // Create Subjects
        Subject sub0 = new Subject("Intro to Programming");
        Subject sub1 = new Subject("Operating Systems and Networks");
        Subject sub2 = new Subject("Web and Mobile Applications");
        Subject sub3 = new Subject("Computer Architecture");
            
        // Add subjects to Manager (chosen to only put this uni directional in the implementation since the subject does not need to know the manager, but could be added)
        systemController.subjects.add(sub0);
        systemController.subjects.add(sub1);
        systemController.subjects.add(sub2);
        systemController.subjects.add(sub3);
            
        // Create Tutors
        Tutor t0 = new Tutor("progtutor@asu.edu", "John Tutor", "tutpass");
        Tutor t1 = new Tutor("optutor@asu.edu", "Tutor May", "password");
        Tutor t2 = new Tutor("webtutor@asu.edu", "Dave Tutor", "tutpassword");
        Tutor t3 = new Tutor("comptutor@asu.edu", "Jane Tutor", "passtutor");
            
        // Add subjects to Manager (needed based on diagram - only implemented uni directional since both directions are not needed)
        systemController.tutors.add(t0);
        systemController.tutors.add(t1);
        systemController.tutors.add(t2);
        systemController.tutors.add(t3);
            
        // Add Subjects to Tutors
        t0.subjects.add(sub0);
        t0.subjects.add(sub1);
        t1.subjects.add(sub1);
        t2.subjects.add(sub2);
        t2.subjects.add(sub3);
        t3.subjects.add(sub3);
        t3.subjects.add(sub0);
            
        // Create Appointments and add to Tutors
        Appointment appt0 = new Appointment(LocalTime.of(10, 0), false, 0, t0, null);
        Appointment appt1 = new Appointment(LocalTime.of(10,30), false, 1, t0, null);
        Appointment appt2 = new Appointment(LocalTime.of(2,30), false, 2, t1, null);
        Appointment appt3 = new Appointment(LocalTime.of(4,0), false, 3, t2, null);
        Appointment appt4 = new Appointment(LocalTime.of(4,30), false, 4, t2, null);
        Appointment appt5 = new Appointment(LocalTime.of(3,30), false, 5, t2, null);
        Appointment appt6 = new Appointment(LocalTime.of(10, 0), false, 6, t2, null);
            
        // Add appointments to appointment list
        mAppointmentController.appointments.add(appt0);
        mAppointmentController.appointments.add(appt1);
        mAppointmentController.appointments.add(appt2);
        mAppointmentController.appointments.add(appt3);
        mAppointmentController.appointments.add(appt4);
        mAppointmentController.appointments.add(appt5);
        mAppointmentController.appointments.add(appt6);
            
            
        // Create Students
        Student s0 = new Student("student@asu.edu", "John Student", "studpass", 5);
        Student s1 = new Student("studentjane@asu.edu", "Jane Student", "pass", 2);
        Student s2 = new Student("studentjack@asu.edu", "Jack Student", "passwo", 1);
        Student s3 = new Student("studentbob@asu.edu", "Bob Student", "studentpass", 0);
            
        // Add students to list
        systemController.students.add(s0);
        systemController.students.add(s1);
        systemController.students.add(s2);
        systemController.students.add(s3);
            
        // Add Appointments to Students
        appt0.student = s1;
        //appt0.booked = true;
        s1.appointments.add(appt0);
            
        // Test Book Appointment method
            
        // Not enough credits case
        System.out.println(sAppointmentController.bookAppointmentBySubjectAndTime("studentbob@asu.edu", "Computer Architecture", LocalTime.of(4, 0).toString()));
            
        // Already an appointment booked
        System.out.println(sAppointmentController.bookAppointmentBySubjectAndTime("studentjane@asu.edu", "Web and Mobile Applications", LocalTime.of(10, 0).toString()));
            
        // No available tutor case
        System.out.println(sAppointmentController.bookAppointmentBySubjectAndTime("student@asu.edu", "Intro to Programming", LocalTime.of(3, 0).toString()));
            
        // Appointment can be booked case
        System.out.println(sAppointmentController.bookAppointmentBySubjectAndTime("studentjack@asu.edu", "Web and Mobile Applications", LocalTime.of(4, 30).toString()));
        
        // test book by id
        // Not enough credits case
        System.out.println(sAppointmentController.BookAppointmentByID("studentbob@asu.edu", 0));
        
        // Already an appointment booked
        System.out.println(sAppointmentController.BookAppointmentByID("studentjane@asu.edu", 6));
        
        // No available tutor case
        System.out.println(sAppointmentController.BookAppointmentByID("student@asu.edu", 0));
        
        // Appointment can be booked case
        System.out.println(sAppointmentController.BookAppointmentByID("studentjack@asu.edu", 1));
    }
    
}
