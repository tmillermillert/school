public class User {

	public String password;

	public String email;

	public String name;
    
    public User(String email, String name, String password) {
        this.email = email;
        this.name = name;
        this.password = password;
    }

}
