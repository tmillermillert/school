import java.util.ArrayList;

public class Manager extends User {
    public Manager(String email, String name, String password) {
        super(email, name, password);
    }
}
