//import java.util.Collection;
import java.util.ArrayList;

public class LoginController {

	public ArrayList<Student> students;

	public ArrayList<Tutor> tutors;

	public Manager manager;

}
