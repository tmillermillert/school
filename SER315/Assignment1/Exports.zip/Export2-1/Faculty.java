import java.util.List;

public class Faculty {

	private final String name;

	private final List professors;

	private final List students;

	private final List courses;

	public String getName() {
		return null;
	}

	public void addProfessors(Professor prof) {

	}

	public List getProfessors() {
		return null;
	}

	public void addCourse(Course course) {

	}

	public List getCourses() {
		return null;
	}

}
