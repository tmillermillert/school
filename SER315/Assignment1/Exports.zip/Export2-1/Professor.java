import java.util.List;

public class Professor {

	private final String name;

	private final Faculty faculty;

	private final List courses;

	public void addCourse(Course course) {

	}

	public List getCourses() {
		return null;
	}

	public String getName() {
		return null;
	}

	public Faculty getFaculty() {
		return null;
	}

}
