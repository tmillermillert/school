public class ID {

	private final Integer id_num;

}
