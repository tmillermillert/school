public class Course {

	private final String name;

	private final int max_students;

	private final Professor professor;

	private final Student[] students;

	public String getName() {
		return null;
	}

	public int getMax() {
		return 0;
	}

	public int getStudentsNumber() {
		return 0;
	}

	public Professor getProf() {
		return null;
	}

}
