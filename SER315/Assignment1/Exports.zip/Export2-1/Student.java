import java.util.List;

public class Student {

	private final String name;

	private final ID id;

	private final List courses;

	private final Faculty faculty;

	public void addCourse(Course course) {

	}

	public List getCourses() {
		return null;
	}

}
