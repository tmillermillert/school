import java.util.List;

public class ControlClass {

	private final List faculties;

	private final List students;

	private final List professors;

	private final List courses;

	public void addFaculty(String name) {

	}

	public void addProfessor(String name, Faculty faculty) {

	}

	public void addCourse(String name, int max_students, Professor prof) {

	}

	public List getFaculties() {
		return null;
	}

	public List getProfessors() {
		return null;
	}

	public List getCourses() {
		return null;
	}

}
