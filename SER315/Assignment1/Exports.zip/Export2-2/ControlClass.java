import java.util.List;

public class ControlClass {

	private Professor[] professors = new ArrayList<Professor>();

	Course[] courses = new ArrayList<Course>();

	private Student[] students = new ArrayList<Student>();

	private Faculty[] faculties = new ArrayList<Faculty>();

	public ControlClass() {

	}

	public void addFaculty(String name) {

	}

	public void addProfessor(String name, Faculty faculty) {

	}

	public void addCourse(String name, int max_students, Professor prof) {

	}

	public List<Faculty> getFaculties() {
		return null;
	}

	public List<Professor> getProfessors() {
		return null;
	}

	public List<Course> getCourses() {
		return null;
	}

}
