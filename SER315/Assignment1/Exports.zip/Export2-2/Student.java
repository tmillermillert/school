import java.util.List;

public class Student {

	private String name;

	private Faculty faculty;

	private Course[] courses = new ArrayList<Course>();

	private ID id;

	public Student(String name, ID id, Faculty faculty) {

	}

	public void addCourse(Course course) {

	}

	public List<Course> getCourses() {
		return null;
	}

}
