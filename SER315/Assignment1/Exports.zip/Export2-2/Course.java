public class Course {

	private String name;

	private int max_students;

	private Student[] students;

	private Professor professor;

	public Course(String name, int max_students, Professor prof) {

	}

	public String getName() {
		return null;
	}

	public int getMax() {
		return 0;
	}

	public int getStudentsNumber() {
		return 0;
	}

	public Professor getProf() {
		return null;
	}

}
