import java.util.List;

public class Faculty {

	private String name;

	private Course[] courses = new ArrayList<Course>();

	private Student[] students = new ArrayList<Student>();

	private Professor[] professors = new ArrayList<Professor>();

	public Faculty(String name) {

	}

	public String getName() {
		return null;
	}

	public void addProfessors(Professor prof) {

	}

	public List<Professor> getProfessors() {
		return null;
	}

	public void addCourse(Course course) {

	}

	public List<Course> getCourses() {
		return null;
	}

}
