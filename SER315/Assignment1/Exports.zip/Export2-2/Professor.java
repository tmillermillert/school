import java.util.List;

public class Professor {

	private String name;

	private Course[] courses = new ArrayList<Course>();

	private Faculty faculty;

	public Professor(String name, Faculty faculty) {

	}

	public void addCourse(Course course) {

	}

	public List<Course> getCourses() {
		return null;
	}

	public String getName() {
		return null;
	}

	public Faculty getFaculty() {
		return null;
	}

}
