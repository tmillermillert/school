public class ID {

	Integer id_num;

	public ID(Integer n) {

	}

}
