public class Student {

	private String name;

	private ID iD;

	private Course[] course;

	private ControlClass controlClass;

	private Faculty faculty;

	public void addCourse(Course course) {

	}

	public List<Course> getCourses() {
		return null;
	}

}
