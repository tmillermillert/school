public class ID {

	private Integer id_num;

	private Student student;

}
