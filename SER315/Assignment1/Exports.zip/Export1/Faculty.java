public class Faculty {

	private String name;

	private Professor[] professor;

	private ControlClass controlClass;

	private Student[] student;

	private Course[] course;

	public String getName() {
		return null;
	}

	public void addProfessor(Professor professor) {

	}

	public List<Professor> getProfessors() {
		return null;
	}

	public void addCourse(Course course) {

	}

	public List<Course> getCourses() {
		return null;
	}

}
