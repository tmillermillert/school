public class Course {

	private String name;

	private int max_students;

	private Professor professor;

	private Student[] student;

	private ControlClass controlClass;

	private Faculty faculty;

	public String getName() {
		return null;
	}

	public int getMax() {
		return 0;
	}

	public int getStudentsNumber() {
		return 0;
	}

	public Professor getProfessor() {
		return null;
	}

}
