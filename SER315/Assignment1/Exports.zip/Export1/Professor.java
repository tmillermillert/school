public class Professor {

	private String name;

	private Course[] course;

	private Faculty faculty;

	private ControlClass controlClass;

	public void addCourse(Course course) {

	}

	public String getName() {
		return null;
	}

	public List<Course> getCourses() {
		return null;
	}

	public Faculty getFaculty() {
		return null;
	}

}
