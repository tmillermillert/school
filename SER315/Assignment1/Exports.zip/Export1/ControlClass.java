public class ControlClass {

	private Professor[] professor;

	private Student[] student;

	private Course[] course;

	private Faculty[] faculty;

	public void addFaculty(String name) {

	}

	public void addProfessor(String name, Faculty faculty) {

	}

	public void addCourse(String name, int max_students, Professor prof) {

	}

	public List<Faculty> getFaculties() {
		return null;
	}

	public List<Professor> getProfessors() {
		return null;
	}

	public List<Course> getCourses() {
		return null;
	}

}
